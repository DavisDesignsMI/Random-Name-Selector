﻿/* Created By Davis M. Brace
 * Started On: 3/26/2019 
 * 
 * DESCRIPTION:
 * This console app allows for changes to the "names.txt" save file.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GeneralFunctions;
using System.IO;
using static System.Net.Mime.MediaTypeNames;

namespace Make_A_Change
{
    class Program
    {
        static void Main(string[] args)
        {
            Methods methods = new Methods();
            string dir = System.IO.Directory.GetCurrentDirectory() + "\\MAIN_PROGRAM\\DATA\\";

            //Get intention from user
            Console.Write("Input your selection (input 1 to delete all names and input new ones, " +
                "2 to delete one name, 3 to add a name(s), or 4 to show all names):  ");
            string selection = Console.ReadLine();

            //Run method corresponding to selection
            switch (selection)
            {
                case "1":
                    methods.DeleteAll();
                    break;

                case "2":
                    methods.DeleteOne();
                    break;

                case "3":
                    methods.Add();
                    break;

                case "4":
                    methods.Show();
                    break;

                default:
                    Console.WriteLine("ERROR");
                    break;
            }

            //PAUSE
            Console.WriteLine("PROCESS COMPLETE: press any key to exit.");
            Console.ReadKey();
        }
    }


    /* AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
     * AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
     * AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
     * AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
     */


    class Methods
    {
        public void DeleteAll()
        {
            //Get directory
            string dir = System.IO.Directory.GetCurrentDirectory() + "\\MAIN_PROGRAM\\DATA\\names.txt";

            //Clear file
            File.WriteAllText(dir, string.Empty);

            //Add new names
            Add();
        }

        //AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

        public void DeleteOne()
        {
            //Initiate vars
            string dir = System.IO.Directory.GetCurrentDirectory() + "\\MAIN_PROGRAM\\DATA\\";
            string toDelete;
            List<string> Names = new List<string>();
            Names = Read();
            string names = null;

            //Erase file
            DeleteAll();

            //Display names
            Show();

            //Get name to delete
            Console.Write("Input name to be deleted:  ");
            toDelete = Console.ReadLine();

            //Remove user input from Names list
            Names.Remove(toDelete + ";");

            //Convert list Names to string
            names = string.Concat(Names.ToArray());

            //Write Names list to file
            GeneralMethods.WriteFile(dir, "names.txt", names);
        }

        //AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

        public void Add()
        {
            //Initiate vars
            string dir = System.IO.Directory.GetCurrentDirectory() + "\\MAIN_PROGRAM\\DATA\\";
            List<string> Names = new List<string>();
            Names = Read();
            string names = null;
            string input = null;
            bool cont = true;

            while (cont)
            {
                //Get user input
                Console.Write("Input name to add or 'done' if you are done:  ");
                string a = Console.ReadLine();

                //Check if user inputted "done" and change cont to false if done
                if (a == "done")
                {
                    cont = false;
                }
                else
                {
                    Names.Add(a + ";");
                    input += a + ";";
                }
            }

            //Convert list Names to string
            names = string.Concat(Names.ToArray());

            //Write Names list to file
            GeneralMethods.WriteFile(dir, "names.txt", names);
        }

        //AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

        public void Show()
        {
            //Initiate vars
            string dir = System.IO.Directory.GetCurrentDirectory() + "\\MAIN_PROGRAM\\DATA\\";
            string names = GeneralMethods.ReadFile(dir, "names.txt");
            string output = null;
            int iternum = 0;
            bool cont = true;

            while (cont)
            {
                if (iternum == names.Length)
                {
                    cont = false;
                }
                else
                {
                    output = GeneralMethods.ReadToInclude(names, iternum, ";");
                    Console.WriteLine(output);
                    iternum += output.Length;
                }
            }
        }

        //AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

        public List<string> Read()
        {
            //Initiate vars
            string dir = System.IO.Directory.GetCurrentDirectory() + "\\MAIN_PROGRAM\\DATA\\";
            List<string> output = new List<string>();
            string names = GeneralMethods.ReadFile(dir, "names.txt");
            int iternum = 0;
            bool cont = true;

            while (cont)
            {
                if (iternum == names.Length)
                {
                    cont = false;
                }
                else
                {
                    string outputb = GeneralMethods.ReadToInclude(names, iternum, ";");
                    output.Add(outputb);
                    iternum += outputb.Length;
                }
            }

            return output;
        }
    }
}
