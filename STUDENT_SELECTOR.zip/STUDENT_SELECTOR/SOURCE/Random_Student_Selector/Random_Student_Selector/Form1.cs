﻿/* CREATED BY: Davis Michael Brace (DMB is FULL COPYRIGHT OWNER)
 * STARTED: 3/26/2019
 * 
 * COMPANY: Davis Designs of Michigan LLC
 * DOMAIN: www.davisdesignsmi.com
 * 
 * DESCRIPTION:
 * This program reads a file called names.txt from a folder called DATA in the executable directory and puts them in a list.
 * The program then takes that list and randomly selects names from it each time the spin button is pressed, never repeating
 * any name.
 */

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using GeneralFunctions;

namespace Random_Student_Selector
{
    public partial class Form1 : Form
    {
        //AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

        //INITIALIZE VARIABLES
        //Create list to hold the index of each name used
        private List<int> UsedNames = new List<int>();
        //Create a list to hold names
        private List<string> Names = new List<string>();
        //Get names in file names.txt and store as a list
        private string names = GeneralMethods.ReadFile(System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\DATA\\", "names.txt");
        //Create int length to hold length of names string
        private int length;
        //Create int lengthNames to hold the number of names stored in file
        private int lengthNames;

        //AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

        //Initialize Form
        public Form1()
        {
            InitializeComponent();
        }

        //AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

        //On Load
        private void Form1_Load(object sender, EventArgs e)
        {
            //Set length
            length = names.Length;

            //Initiate local vars
            int iternum = 0;
            bool cont = true;

            //Add names to Names list
            while (cont)
            {
                if (iternum < length)
                {
                    //Add name to list
                    string reading = GeneralMethods.ReadToExclude(names, iternum, ";");
                    Names.Add(reading);

                    //Increase iternum
                    iternum += reading.Length + 1;
                }
                else
                {
                    //Set cont to false to exit loop
                    cont = false;
                }
            }
        }

        //AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

        //Reset
        private void label1_Click(object sender, EventArgs e)
        {
            //Clear UsedNames
            UsedNames.Clear();
            //Reset data count of UesdNames
            UsedNames.TrimExcess();
            //Clear textbox1
            textBox1.Text = null;
        }

        //AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

        //Spin
        private void button1_Click(object sender, EventArgs e)
        {
            //Clear textbox1
            textBox1.Text = null;

            //Reset if all names have been used
            if (UsedNames.Count >= Names.Count)
            {
                //Clear UsedNames
                UsedNames.Clear();
                //Reset data count of UesdNames
                UsedNames.TrimExcess();
            }

            //Set lengthNames
            lengthNames = Names.Count;
            //Create run value
            bool run = true;

            //Generate random number 
            Random rnd = new Random();
            int checking = rnd.Next(0, lengthNames);

            while (run)
            {
                //Get name at index of checking
                if (UsedNames.Contains(checking))
                {
                    //Generate random number 
                    Random rand = new Random();
                    checking = rand.Next(0, lengthNames);
                }
                else
                {
                    //Add int checking to list UsedNames
                    UsedNames.Add(checking);
                    //Display chosen name In textbox1
                    textBox1.Text = Names[checking];
                    //Set run to false to stop loop
                    run = false;
                }
            }
        }

        //AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
    }
}
